
#include "console.h"

#include "Gwen/Skins/TexturedBase.h"
#include "Gwen/Controls.h"

#include <string>

#define GAME_NAME						"DOOM 3: BFG Edition"		// appears on window titles and errors

static std::string consoleLog = std::string();

Console::Console(void * modal) : Gwen::Controls::Base(NULL), m_modal(modal)
{
	m_ConsoleRenderer = NULL;
	m_ConsoleCanvas = NULL;
	m_StatusBar = NULL;
	m_consoleLogBox = NULL;
	m_consoleComandInput = NULL;
	m_lastErrorBox = NULL;
}

Console::~Console()
{
}

void Console::CreateConsole(void)
{
	// Create a GWEN Renderer
	m_ConsoleRenderer = new Gwen::Renderer::SDL();

	// Create a GWEN skin
	Gwen::Skin::TexturedBase* pSkin = new Gwen::Skin::TexturedBase(m_ConsoleRenderer);

	//preload the font
	m_ConsFont.facename = L"fonts/consolab.ttf";
	m_ConsFont.size = 12;
	m_ConsoleRenderer->LoadFont(&m_ConsFont);

	// Create a Canvas (it's root, on which all other GWEN panels are created)
	m_ConsoleCanvas = new Gwen::Controls::WindowCanvas(-1, -1, k_consWidth, k_consHeight, pSkin,	GAME_NAME, SDL_WINDOW_UTILITY);

	// The fonts work differently in sdl - it can't use
	// system fonts. So force the skin to use a local one.
	pSkin->Init("mainSkin.bmp");
	pSkin->SetDefaultFont(L"fonts/courier.ttf", 12);

	m_ConsoleCanvas->SetDrawBackground(true);
	m_ConsoleCanvas->SetBackgroundColor(Gwen::Color(150, 170, 170, 255));
}

void Console::DestroyConsole(void)
{
	delete m_ConsoleCanvas;
	m_ConsoleCanvas = NULL;
	delete m_ConsoleRenderer;
	m_ConsoleRenderer = NULL;
}

void Console::ShowConsole(int visLevel, bool quitOnClose, bool paralel)
{
	//create the windgets
	createWindowLayout(visLevel);

	if (paralel)
	{
		void* ThreadParam = reinterpret_cast<void*>(this);
		//TODO
	}
	else
	{
		RunConsole();
	}
}

const char * Console::ConsoleInput(void)
{
	return consoleLog.c_str();
}

void Console::SetErrorText(const char * buf)
{
	Gwen::TextObject console = buf;
	m_lastErrorBox->SetText(console);
}

void Console::ConsoleAppendText(const char * pMsg)
{
	consoleLog.append(pMsg + std::string("\n"));
}

void Console::createWindowLayout(int visLevel)
{
	//the status Bar
	{
		m_StatusBar = new Gwen::Controls::StatusBar(m_ConsoleCanvas);
		m_StatusBar->SetPadding(Gwen::Padding(0, 0, 0, 0));
		m_StatusBar->SetMargin(Gwen::Margin(0, 0, 0, 0));
		m_StatusBar->Dock(Gwen::Pos::Bottom);
		m_StatusBar->SendToBack();

	}
	{
		Gwen::Controls::Layout::Tile * ButtonTabble = new Gwen::Controls::Layout::Tile(m_ConsoleCanvas);
		ButtonTabble->SetPadding(Gwen::Padding(0, 0, 0, 0));
		ButtonTabble->SetMargin(Gwen::Margin(4, 2, 4, 2));
		ButtonTabble->SetHeight(24);
		ButtonTabble->Dock(Gwen::Pos::CenterH | Gwen::Pos::Bottom);
		//Copy Btn
		{
			Gwen::Controls::Button * CopyBtn = new Gwen::Controls::Button(ButtonTabble, "Copy");
			CopyBtn->SetText(L"copy");
			CopyBtn->SetWidth(72);
			CopyBtn->onPress.Add(this, &Console::onButtonCopy);
			CopyBtn->Dock(Gwen::Pos::Left);
		}
		//Clear Btn
		{
			Gwen::Controls::Button * ClerBtn = new Gwen::Controls::Button(ButtonTabble, "Clear");
			ClerBtn->SetText(L"Clear");
			ClerBtn->SetWidth(72);
			ClerBtn->SetMargin(Gwen::Margin(2, 0, 0, 0));
			ClerBtn->onPress.Add(this, &Console::onButtonClear);
			ClerBtn->Dock(Gwen::Pos::Left);
		}
		//Quit Btn
		{
			Gwen::Controls::Button * QutnBtn = new Gwen::Controls::Button(ButtonTabble, "Quit");
			QutnBtn->SetText(L"Quit");
			QutnBtn->SetWidth(72);
			QutnBtn->onPress.Add(this, &Console::onButtonQuit);
			QutnBtn->Dock(Gwen::Pos::Right);
		}
	}
	//Input controls
	if(visLevel > 0)
	{
		Gwen::Controls::Layout::Tile * InputTabble = new Gwen::Controls::Layout::Tile(m_ConsoleCanvas);
		InputTabble->SetPadding(Gwen::Padding(0, 0, 0, 0));
		InputTabble->SetMargin(Gwen::Margin(4, 2, 4, 2));
		InputTabble->SetHeight(24);
		InputTabble->Dock(Gwen::Pos::CenterH | Gwen::Pos::Bottom);
		//Submit Btn
		{
			Gwen::Controls::Button * SubmitBtn = new Gwen::Controls::Button(InputTabble, "Submit");
			SubmitBtn->SetText(L"Submit");
			SubmitBtn->SetTextColor(Gwen::Color(0, 0, 0, 255));
			SubmitBtn->SetWidth(72);
			SubmitBtn->onPress.Add(this, &Console::onSubmitTextConsole);
			SubmitBtn->Dock(Gwen::Pos::Right);
		}
		{
			m_consoleComandInput = new Gwen::Controls::TextBox(InputTabble, "ImputLabel");
			m_consoleComandInput->SetText("");
			m_consoleComandInput->SetWidth(455);
			m_consoleComandInput->SetCursor(1);
			m_consoleComandInput->Dock(Gwen::Pos::Left);
			m_consoleComandInput->onReturnPressed.Add(this, &Console::onSubmitTextConsole);
		}
	}
	{
		Gwen::Controls::Layout::Tile * LogTabble = new Gwen::Controls::Layout::Tile(m_ConsoleCanvas);
		LogTabble->SetPadding(Gwen::Padding(0, 0, 0, 0));
		LogTabble->SetMargin(Gwen::Margin(4, 2, 4, 2));
		LogTabble->SetHeight(390);
		LogTabble->Dock(Gwen::Pos::CenterH | Gwen::Pos::Top);
		//Error Text Box
		{
			m_lastErrorBox = new Gwen::Controls::TextBox(LogTabble);
			m_lastErrorBox->SetSize(526, 30);
			m_lastErrorBox->SetEditable(false);
			m_lastErrorBox->SetTextColor(Gwen::Color(255, 0, 0, 255)); //RED color for the Console
			m_lastErrorBox->SetShouldDrawBackground(true);
			m_lastErrorBox->SetMargin(Gwen::Margin(0, 2, 0, 2));
			m_lastErrorBox->Dock(Gwen::Pos::CenterV | Gwen::Pos::Top);
		}
		//Log text box
		{
			m_consoleLogBox = new Gwen::Controls::TextBoxMultiline(LogTabble);
			m_consoleLogBox->SetFont(&m_ConsFont);
			m_consoleLogBox->SetTextColor(Gwen::Color(0, 0, 0, 255));
			m_consoleLogBox->SetSize(526, 354);
			m_consoleLogBox->SetShouldDrawBackground(true);
			//m_consoleLogBox->SetBackgroundColor(Gwen::Color(150, 170, 170, 255));
			m_consoleLogBox->SetCursor(1);
			m_consoleLogBox->SetMargin(Gwen::Margin(0, 2, 0, 0));
			m_consoleLogBox->Dock(Gwen::Pos::CenterV | Gwen::Pos::Bottom);
		}
		
	}
}

int Console::StaticEntryPoint(void* Ptr)
{
	Console* ConsoleHandler = reinterpret_cast<Console*>(Ptr);

	if (ConsoleHandler)
		ConsoleHandler->RunConsole();

	return 0;
}

void Console::RunConsole(void)
{
	// program main loop
	m_done = false;
	while (!m_done)
	{
		// if it's QUIT then quit..
		if (m_ConsoleCanvas->WantsQuit())
			m_done = true;

		// DRAWING STARTS HERE
		m_ConsoleCanvas->DoThink();
	} // end main loop
}

void Console::onButtonCopy(Gwen::Controls::Base * pControl)
{
	Gwen::TextObject log = m_consoleLogBox->GetText();
	Gwen::Platform::SetClipboardText(log.GetUnicode());
	printf("console log copied\n");
}

void Console::onButtonClear(Gwen::Controls::Base * pControl)
{
	m_consoleLogBox->SetText("");
	printf("console log clear\n");
}

void Console::onButtonQuit(Gwen::Controls::Base * pControl)
{
	//send a close comand
	m_ConsoleCanvas->InputQuit();
}

void Console::onSetStatusBarText(Gwen::Controls::Base * pControl, void * text)
{
	const wchar_t * Vec = (wchar_t*)text;
	m_StatusBar->SetTextColor(Gwen::Color(0, 0, 0, 0xff));
	m_StatusBar->SetText(Vec);
}

void Console::onSubmitTextConsole(Gwen::Controls::Base * pControl)
{
	//get the text from imput and send to the game console
	Gwen::TextObject command = m_consoleComandInput->GetText();
	ConsoleAppendText(command.c_str());

	m_consoleComandInput->SetText(L"");

	//get the game console and send to the log output
	Gwen::TextObject console =	ConsoleInput();
	m_consoleLogBox->SetText(console);
}
