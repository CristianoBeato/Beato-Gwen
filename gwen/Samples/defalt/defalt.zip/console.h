
#ifndef _CONSOLE_H_
#define _CONSOLE_H_

#include "Gwen/Gwen.h"
#include "Gwen/Controls.h"

enum MyEnum
{
	CONS_MODE_ERR = 0,
	CONS_MODE_SHORT = 1,
	CONS_MODE_FULL = 2
};


class Console : public Gwen::Controls::Base
{
	static const int k_consWidth = 540;
	static const int k_consHeight = 474;
public:
	Console(void * modal = nullptr);
	~Console();

	void		CreateConsole(void);
	void		DestroyConsole(void);
	void		ShowConsole(int visLevel, bool quitOnClose, bool paralel = false);

	const char*	ConsoleInput(void);
	void		SetErrorText(const char* buf);
	void		ConsoleAppendText(const char* pMsg);

private:
	void	createWindowLayout(int visLevel);
	static int StaticEntryPoint(void* Ptr);
	void RunConsole(void);

	//callbacks
	void onButtonCopy(Gwen::Controls::Base* pControl);
	void onButtonClear(Gwen::Controls::Base* pControl);
	void onButtonQuit(Gwen::Controls::Base* pControl);
	void onSetStatusBarText(Gwen::Controls::Base* pControl, void* text);
	void onSubmitTextConsole(Gwen::Controls::Base* pControl);
	
	bool									m_done;
	void*									m_modal;
	Gwen::Font								m_ConsFont;
	Gwen::Renderer::Base*					m_ConsoleRenderer;
	Gwen::Controls::WindowCanvas*			m_ConsoleCanvas;
	Gwen::Controls::StatusBar*				m_StatusBar;
	Gwen::Controls::TextBox*				m_consoleComandInput;
	Gwen::Controls::TextBox*				m_lastErrorBox;
	Gwen::Controls::TextBoxMultiline*		m_consoleLogBox;
};

#endif // !_CONSOLE_H_
