/*
===========================================================================
GWEN

Copyright (c) 2010 Facepunch Studios
Copyright (c) 2017-2018 Cristiano Beato

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
===========================================================================
*/

#include "precompiled.h"
#pragma hdrstop

#include <math.h>
#include "Gwen/Controls/Slider.h"

using namespace Gwen;
using namespace Gwen::Controls;
using namespace Gwen::ControlsInternal;

GWEN_CONTROL_CONSTRUCTOR( SliderBar )
{
	SetTarget( this );
	RestrictToParent( true );
}

void SliderBar::Render( Skin::Base* skin )
{
	skin->DrawSlideButton( this, IsDepressed(), IsHorizontal() );
}


GWEN_CONTROL_CONSTRUCTOR( Slider )
{
	SetBounds( Gwen::Rect( 0, 0, 32, 128 ) );
	m_SliderBar = new SliderBar( this );
	m_SliderBar->onDragged.Add( this, &Slider::OnMoved );
	m_fMin = 0.0f;
	m_fMax = 1.0f;
	m_bClampToNotches = false;
	m_iNumNotches = 5;
	m_fValue = 0.0f;
	SetTabable( true );
}

void Slider::OnMoved( Controls::Base* /*control*/ )
{
	SetValueInternal( CalculateValue() );
}

void Slider::Layout( Skin::Base* skin )
{
	BaseClass::Layout( skin );
}

float Slider::CalculateValue()
{
	return 0;
}

void Slider::SetFloatValue( float val, bool /*forceUpdate*/ )
{
	if ( val < m_fMin ) { val = m_fMin; }

	if ( val > m_fMax ) { val = m_fMax; }

	// Normalize Value
	val = ( val - m_fMin ) / ( m_fMax - m_fMin );
	SetValueInternal( val );
	Redraw();
}

void Slider::SetValueInternal( float val )
{
	if ( m_bClampToNotches )
	{
		val = floorf( ( val * ( float ) m_iNumNotches ) + 0.5f );
		val /= ( float ) m_iNumNotches;
	}

	if ( m_fValue != val )
	{
		m_fValue = val;
		onValueChanged.Call( this );
	}

	UpdateBarFromValue();
}

float Slider::GetFloatValue()
{
	return m_fMin + ( m_fValue * ( m_fMax - m_fMin ) );
}

void Slider::SetRange( float fMin, float fMax )
{
	m_fMin = fMin;
	m_fMax = fMax;
}

void Slider::RenderFocus( Gwen::Skin::Base* skin )
{
	if ( Gwen::KeyboardFocus != this ) { return; }

	if ( !IsTabable() ) { return; }

	skin->DrawKeyboardHighlight( this, GetRenderBounds(), 0 );
}

void Slider::OnBoundsChanged(Gwen::Rect oldBounds)
{
	BaseClass::OnBoundsChanged( oldBounds );
	UpdateBarFromValue();
}
